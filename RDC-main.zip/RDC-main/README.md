# Hospital-Management

Freelanced as a Frontend Developer for a hospital management website which is made using Reactjs, Tailwind and Sanity. Patients can register for their appointments and explore insights about the hospital. It has the functionality of SMS delivery and Real time Database Updates. (Backend Dev - @SaarD00)

![image](https://user-images.githubusercontent.com/85481905/210169810-f02f98b6-86fe-4fb8-acb0-20657d6b31bd.png)
