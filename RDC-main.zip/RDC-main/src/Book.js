import React from "react";
import Booking from "./components/Booking";

function Book() {
  return (
    <Booking/>
  );
}

export default Book;
