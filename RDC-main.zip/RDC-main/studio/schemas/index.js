import post from './post'

export const schemaTypes = [post]
