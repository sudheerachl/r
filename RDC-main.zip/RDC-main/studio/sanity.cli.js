import {defineCliConfig} from 'sanity/cli'

export default defineCliConfig({
  api: {
    projectId: '0idhl247',
    dataset: 'production'
  }
})
